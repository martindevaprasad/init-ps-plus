import { connectDB } from '../src/config/database';
import app from '../src/server';

export default async (req: any, res: any) => {
  // Ensure database is connected before handling the request
  await connectDB();
  
  // Let Express handle the request
  return app(req, res);
};
