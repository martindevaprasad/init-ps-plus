import mongoose from 'mongoose';

let cachedConnection: typeof mongoose | null = null;

export const connectDB = async (): Promise<void> => {
  if (cachedConnection) {
    return;
  }

  const uri = process.env.MONGODB_URI || 'mongodb://localhost:27017/restaurant_pos';
  
  try {
    const conn = await mongoose.connect(uri);
    cachedConnection = conn;
    console.log('✅ Connected to MongoDB');
  } catch (error) {
    console.error('❌ MongoDB connection error:', error);
    throw error;
  }
};
