import mongoose, { Connection } from 'mongoose';
import { productSchema } from '../services/inventory/models/Product';
import { orderSchema } from '../services/order/models/Order';
import { paymentSchema } from '../services/payment/models/Payment';
import { inventoryLogSchema } from '../services/inventory/models/InventoryLog';
import { categorySchema } from '../services/inventory/models/Category';

const tenantConnections: { [key: string]: Connection } = {};

export const getTenantConnection = (tenantId: string): Connection => {
  if (tenantConnections[tenantId]) {
    return tenantConnections[tenantId];
  }

  // Create a new connection to the tenant's database
  // useDb creates a new connection object to a different database using the same connection pool
  const db = mongoose.connection.useDb(`tenant_${tenantId}`, { useCache: true });

  // Register tenant-specific models
  db.model('Category', categorySchema);
  db.model('Product', productSchema);
  db.model('Order', orderSchema);
  db.model('Payment', paymentSchema);
  db.model('InventoryLog', inventoryLogSchema);

  tenantConnections[tenantId] = db;
  return db;
};
