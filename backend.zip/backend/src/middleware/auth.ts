import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';

import { Connection, Model } from 'mongoose';
import { ICategory } from '../services/inventory/models/Category';
import { IProduct } from '../services/inventory/models/Product';
import { IOrder } from '../services/order/models/Order';
import { IPayment } from '../services/payment/models/Payment';
import { IInventoryLog } from '../services/inventory/models/InventoryLog';

export interface AuthRequest extends Request {
  user?: { id: string; username: string; email: string; role: string; accessibleTenants?: string[] };
  tenantDb?: Connection;
  tenantModels?: {
    Category: Model<ICategory>;
    Product: Model<IProduct>;
    Order: Model<IOrder>;
    Payment: Model<IPayment>;
    InventoryLog: Model<IInventoryLog>;
  };
}

export const authenticateToken = (req: AuthRequest, res: Response, next: NextFunction) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader?.split(' ')[1];
  if (!token) return res.status(401).json({ success: false, error: { code: 'NO_TOKEN', message: 'Access token required' } });

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'jwt_secret') as any;
    req.user = decoded;
    next();
  } catch {
    res.status(401).json({ success: false, error: { code: 'INVALID_TOKEN', message: 'Invalid access token' } });
  }
};

export const authorizeRole = (roles: string[]) => (req: AuthRequest, res: Response, next: NextFunction) => {
  if (!req.user || !roles.includes(req.user.role)) {
    return res.status(403).json({ success: false, error: { code: 'FORBIDDEN', message: 'Access denied' } });
  }
  next();
};
