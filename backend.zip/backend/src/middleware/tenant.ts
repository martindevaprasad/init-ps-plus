import { Response, NextFunction } from 'express';
import { AuthRequest } from './auth';
import { getTenantConnection } from '../config/tenantConnection';
import Tenant from '../services/auth/models/Tenant';

export const tenantMiddleware = async (req: AuthRequest, res: Response, next: NextFunction) => {
  try {
    const tenantId = req.headers['x-tenant-id'] as string;

    if (!tenantId) {
      return res.status(400).json({ success: false, error: { code: 'NO_TENANT', message: 'x-tenant-id header is required' } });
    }

    // Verify tenant exists in the public DB
    // Verify tenant exists in the public DB
    const tenantExists = await Tenant.findOne({ tenantId, isActive: true });
    if (!tenantExists) {
      return res.status(403).json({ success: false, error: { code: 'INVALID_TENANT', message: 'Invalid or inactive tenant' } });
    }

    // If user is authenticated, check if they have access to this tenant
    // Assuming admin can access any, otherwise check accessibleTenants
    if (req.user && req.user.role !== 'admin') {
      if (!req.user.accessibleTenants?.includes(tenantId)) {
        return res.status(403).json({ success: false, error: { code: 'FORBIDDEN_TENANT', message: 'You do not have access to this tenant branch' } });
      }
    }

    // Get the dynamic database connection for this tenant
    const tenantDb = getTenantConnection(tenantId);
    
    // Inject tenant DB and models into the request
    req.tenantDb = tenantDb;
    req.tenantModels = {
      Category: tenantDb.model('Category'),
      Product: tenantDb.model('Product'),
      Order: tenantDb.model('Order'),
      Payment: tenantDb.model('Payment'),
      InventoryLog: tenantDb.model('InventoryLog'),
    };

    next();
  } catch (error: any) {
    res.status(500).json({ success: false, error: { code: 'TENANT_ROUTING_ERROR', message: error.message } });
  }
};
