import { Router } from 'express';
import { getAllCategories, createCategory, updateCategory, deleteCategory } from '../controllers/categoryController';
import { authenticateToken, authorizeRole } from '../../../middleware/auth';

const r = Router();

r.get('/', authenticateToken, getAllCategories);
r.post('/', authenticateToken, authorizeRole(['admin', 'manager']), createCategory);
r.put('/:id', authenticateToken, authorizeRole(['admin', 'manager']), updateCategory);
r.delete('/:id', authenticateToken, authorizeRole(['admin', 'manager']), deleteCategory);

export default r;
