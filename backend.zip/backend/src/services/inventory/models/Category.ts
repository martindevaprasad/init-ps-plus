import { Document, Schema, Types } from 'mongoose';

export interface ICategory extends Document {
  name: string;
  parentCategory: Types.ObjectId | null;
  description?: string;
  isActive: boolean;
}

export const categorySchema = new Schema({
  name: { type: String, required: true, trim: true },
  parentCategory: { type: Schema.Types.ObjectId, ref: 'Category', default: null },
  description: { type: String, trim: true },
  isActive: { type: Boolean, default: true },
}, { timestamps: true });

// Note: Model compilation happens in tenantConnection.ts
