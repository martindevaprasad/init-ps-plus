import { Response } from 'express';
import { AuthRequest } from '../../../middleware/auth';

export const getAllCategories = async (req: AuthRequest, res: Response) => {
  try {
    const categories = await req.tenantModels!.Category.find().populate('parentCategory');
    res.json({ success: true, data: categories });
  } catch (err: any) { res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: err.message } }); }
};

export const createCategory = async (req: AuthRequest, res: Response) => {
  try {
    const { name, parentCategory, description } = req.body;
    const category = await new req.tenantModels!.Category({ name, parentCategory: parentCategory || null, description }).save();
    res.status(201).json({ success: true, data: category });
  } catch (err: any) { res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: err.message } }); }
};

export const updateCategory = async (req: AuthRequest, res: Response) => {
  try {
    const category = await req.tenantModels!.Category.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!category) return res.status(404).json({ success: false, error: { code: 'NOT_FOUND', message: 'Category not found' } });
    res.json({ success: true, data: category });
  } catch (err: any) { res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: err.message } }); }
};

export const deleteCategory = async (req: AuthRequest, res: Response) => {
  try {
    await req.tenantModels!.Category.findByIdAndUpdate(req.params.id, { isActive: false });
    res.json({ success: true, data: { message: 'Category deactivated' } });
  } catch (err: any) { res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: err.message } }); }
};
