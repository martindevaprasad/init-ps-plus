import mongoose, { Document, Schema } from 'mongoose';

export interface ITenant extends Document {
  name: string;
  tenantId: string;
  isActive: boolean;
  address?: string;
  contactNumber?: string;
}

const tenantSchema = new Schema({
  name: { type: String, required: true, trim: true },
  tenantId: { type: String, required: true, unique: true, lowercase: true, trim: true },
  isActive: { type: Boolean, default: true },
  address: { type: String },
  contactNumber: { type: String },
}, { timestamps: true });

export default mongoose.model<ITenant>('Tenant', tenantSchema);
